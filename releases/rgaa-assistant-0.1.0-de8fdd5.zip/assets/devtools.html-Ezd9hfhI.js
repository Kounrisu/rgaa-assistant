import"./modulepreload-polyfill-B5Qt9EMX.js";chrome.devtools.panels.create("RGAA Assistant","","/src/panel/panel.html");
