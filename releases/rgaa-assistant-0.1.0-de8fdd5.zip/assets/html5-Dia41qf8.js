import{b as t}from"./elements-CrAWx8gf.js";var l=t.html5;export{l as default};
